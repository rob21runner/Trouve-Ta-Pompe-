# Trouve ta Pompe

Trouve ta pompe est un package python qui permet aux différents utilisateurs de trouver des pompes à carburant autour de leur position. Actuellement elle répertori toutes les stations essences dans un rayon de 35km autour de la position donné ou estimé via l'ip de l'utilisateur.

## Bien débuter