from .map import create_map


def show_map():
    create_map()
