# Trouve ta Pompe

Trouve ta pompe est un package python qui permet aux différents utilisateurs de trouver des pompes à carburant autour de leur position. Actuellement elle répertori toutes les stations essences dans un rayon de 35km autour de la position donné ou estimé via l'ip de l'utilisateur.

## Bien débuter

Pour installer le package ainsi que toutes ses dépendances veuillez executer la commande suivante :
```bash
pip install branca==0.4.2 folium==0.11.0 geopy==2.3.0 numpy==1.23 plotly==5.14.0 pandas==1.5.3 scikit-learn==1.2.2 seaborn==0.12.2 selenium==4.0.0 requests==2.28.2
```