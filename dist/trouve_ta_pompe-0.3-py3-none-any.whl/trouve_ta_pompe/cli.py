#!/usr/bin/env python

from trouve_ta_pompe import show_map

def main():
    show_map()

if __name__ == "__main__":
    main()