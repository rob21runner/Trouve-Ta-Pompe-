from .map import create_map


def show_map():
    map.create_map()