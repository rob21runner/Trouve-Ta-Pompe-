from setuptools import setup

setup(
    name="trouve_ta_pompe",
    version="0.3",
    author="Guerard Robin, Maureen Metge, Nazir Youssouf",
    packages=["trouve_ta_pompe"],
    install_requires=['folium', 'requests', 'branca', 'numpy', 'pandas', 'geopy'],
    entry_points={
        "console_scripts": [
            "trouve=trouve_ta_pompe.cli:main",
        ],
    },
)